// Exercice 8: Calcul de l'aire d'un cercle
module.exports = function aireCercle(rayon) {
    return Math.PI * Math.pow(rayon, 2);
}
