// Exercice 3: Multiplication de deux nombres
module.exports = function multiplication(a, b) {
    return a * b;
}
