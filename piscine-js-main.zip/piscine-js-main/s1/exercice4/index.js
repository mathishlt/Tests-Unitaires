// Exercice 4: Division de deux nombres
module.exports = function division(a, b) {
    return a / b;
}  