// Exercice 7: Conversion de température de Celsius à Fahrenheit
module.exports = function celsiusEnFahrenheit(celsius) {
    return celsius * 9 / 5 + 32;
}
