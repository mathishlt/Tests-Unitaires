// Exercice 2: Soustraction de deux nombres
module.exports = function soustraction(a, b) {
    return a - b;
}
