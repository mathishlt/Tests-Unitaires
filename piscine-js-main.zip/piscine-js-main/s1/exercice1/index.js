// Exercice 1: Addition de deux nombres
module.exports = function addition(a, b) {
    return a + b;
}